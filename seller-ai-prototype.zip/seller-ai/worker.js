const corsHeaders = { 'Access-Control-Allow-Origin': '*', 'Access-Control-Allow-Methods': 'POST, OPTIONS', 'Access-Control-Allow-Headers': 'Content-Type' };
const json = (body, status=200) => new Response(JSON.stringify(body), {status, headers:{'Content-Type':'application/json; charset=utf-8', ...corsHeaders}});
export default {
 async fetch(request, env) {
  const url = new URL(request.url);
  if (request.method === 'OPTIONS') return new Response(null,{headers:corsHeaders});
  if (url.pathname === '/api/health') return json({ok:true,service:'SELLER AI',version:'1.0.0'});
  if (url.pathname !== '/api/generate') return env.ASSETS.fetch(request);
  if (request.method !== 'POST') return json({error:'Используйте POST-запрос.'},405);
  if (!env.AI) return json({error:'ИИ не подключён. Проверьте AI binding в настройках Cloudflare.'},503);
  let form; try { form = await request.formData(); } catch { return json({error:'Не удалось прочитать форму. Загрузите фото ещё раз.'},400); }
  const image = form.get('image');
  if (!(image instanceof File)) return json({error:'Добавьте фотографию товара.'},400);
  if (!['image/jpeg','image/png','image/webp'].includes(image.type)) return json({error:'Формат не поддерживается. Используйте JPG, PNG или WebP.'},415);
  if (image.size > 5*1024*1024) return json({error:'Размер фотографии превышает 5 МБ.'},413);
  const fields = Object.fromEntries(['name','price','condition','platform','tone','extra'].map(k=>[k,String(form.get(k)||'').slice(0, k==='extra'?1000:120)]));
  const bytes = new Uint8Array(await image.arrayBuffer());
  let binary=''; for(let i=0;i<bytes.length;i+=0x8000) binary += String.fromCharCode(...bytes.subarray(i,i+0x8000));
  const base64 = btoa(binary);
  const prompt = `Ты — профессиональный русскоязычный специалист по продажам. Проанализируй фото товара и создай честное объявление для ${fields.platform||'универсальной площадки'}. Стиль: ${fields.tone||'убедительный и дружелюбный'}. Данные пользователя: название=${fields.name||'не указано'}; цена=${fields.price||'не указана'}; состояние=${fields.condition||'не указано'}; дополнительные сведения=${fields.extra||'нет'}. Не выдумывай бренд, модель, состояние, комплект, характеристики, гарантию, цену или результаты тестов. Отличай наблюдаемое на фото от предположений. Если точная модель неясна, скажи об этом. Не утверждай, что товар новый/исправный, если это не подтверждено. Создай заголовок до 100 символов, естественное описание на 2-4 абзаца, короткую рекламу, 3-6 особенностей, 2-4 наблюдения с фото, список того, что продавцу нужно уточнить (если нужно), и 3-6 хештегов. Верни только валидный JSON с ключами title, description, short_ad, features (массив строк), photo_observations (массив строк), missing_information (массив строк), hashtags (массив строк), disclaimer (строка). Не добавляй markdown.`;
  try {
   const response = await env.AI.run('@cf/meta/llama-3.2-11b-vision-instruct', {messages:[{role:'user',content:prompt}], image:`data:${image.type};base64,${base64}`, max_tokens:1100});
   let raw = response?.response || response?.output_text || response?.result?.response || '';
   if (!raw && typeof response === 'string') raw=response;
   const match = raw.match(/\{[\s\S]*\}/);
   if (!match) throw new Error('Модель вернула ответ в неожиданном формате. Попробуйте ещё раз.');
   let parsed; try { parsed=JSON.parse(match[0]); } catch { throw new Error('Не удалось обработать ответ ИИ. Попробуйте ещё раз.'); }
   const clean = (v,max=4000)=>typeof v==='string'?v.trim().slice(0,max):'';
   const arr = v=>Array.isArray(v)?v.filter(x=>typeof x==='string').slice(0,10).map(x=>x.trim().slice(0,300)):[];
   if(!clean(parsed.title,150)||!clean(parsed.description)) throw new Error('ИИ не смог создать полноценное объявление. Попробуйте другое фото.');
   return json({title:clean(parsed.title,150),description:clean(parsed.description),short_ad:clean(parsed.short_ad,1000),features:arr(parsed.features),photo_observations:arr(parsed.photo_observations),missing_information:arr(parsed.missing_information),hashtags:arr(parsed.hashtags),disclaimer:'Проверьте точность характеристик и дополните неизвестные сведения перед публикацией.'});
  } catch(e) {
   const message = e?.message || '';
   if (/rate|limit|quota|neurons|billing/i.test(message)) return json({error:'Достигнут лимит запросов ИИ. Попробуйте позже или проверьте лимиты Cloudflare Workers AI.'},429);
   if (/image|vision|model|not found|unsupported/i.test(message)) return json({error:'Не удалось обработать это изображение. Попробуйте более чёткое фото товара.'},502);
   return json({error:message.startsWith('Модель')||message.startsWith('Не удалось')||message.startsWith('ИИ')?message:'Сервис ИИ временно недоступен. Попробуйте ещё раз чуть позже.'},502);
  }
 }
};
